#ifndef TRANSFORMA_H
#define TRANSFORMA_H

#include "afnd.h" 
#include <stdbool.h>

AFND *AFNDMinimiza(AFND *afd, bool debug);

#endif